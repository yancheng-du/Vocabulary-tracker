// background.js
chrome.runtime.onInstalled.addListener(function() {
    console.log("Extension installed.");
  });